# Installing Prodigy X On Mobile

Watch this video to figure out how to install on your mobile devices!

![type:video](https://www.youtube.com/embed/astYzqJkg1E)