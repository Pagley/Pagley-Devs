<center>

# Prodigy X

![Logo](https://cdn.discordapp.com/attachments/852986451896959026/980097446589915177/IMG_3310.png)

Prodigy X is a cheat menu for the game [Prodigy](https://www.prodigygame.com/main-en/).

To use Prodigy X, go to our [installing page](installing.md).

For more help visit our [discord server](https://discord.gg/YRtwBJrmGa).
</center>

!!! tip "Always use an alt, just to be safe."
    While our hacks are completely safe, **you should never use hacks on your main account.**
    There's an **extremely slim** chance that you could get banned for using hacks. If you do get banned, please [report it](https://discord.gg/YRtwBJrmGa).