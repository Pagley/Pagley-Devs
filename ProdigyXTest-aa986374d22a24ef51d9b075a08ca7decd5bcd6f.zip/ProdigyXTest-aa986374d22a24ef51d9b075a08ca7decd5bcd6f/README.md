<h1 align="center">Prodigy X</h1>
<br />
<p align="center">
    <img alt="Prodigy X Logo" src="https://media.discordapp.net/attachments/963933103632564335/980916202840920104/unknown.png">
</p>
<br />
<p align="center">
	<strong>
		<a href="https://prodigyapi.github.io/ProdigyX/">Website</a>
		•
		<a href="https://discord.com/invite/YRtwBJrmGa">Discord Server</a>
        •
        <a href="https://prodigyapi.github.io/ProdigyX/installing/">Installation Guide</a>
        •
        <a href="https://www.youtube.com/channel/UCioIJQ4niel1ziD7YA5b3cA">YouTube</a>
	</strong>
    <br />
    <br />
    <a href="https://chrome.google.com/webstore/detail/prodigy-x-loader/eajlgdnpohfeclpikjpnhadfkboknaop">
	    <img alt="Extension Downloads" src="https://img.shields.io/chrome-web-store/users/eajlgdnpohfeclpikjpnhadfkboknaop?color=green&label=Extension%20Downloads">
    </a>
    <a>
	    <img alt="Visitors" src="https://visitor-badge.glitch.me/badge?page_id=ProdigyAPI.ProdigyX">
    </a>
    <a href="https://discord.com/invite/YRtwBJrmGa">
	    <img alt="Discord Members" src="https://img.shields.io/discord/957314086037782638.svg?color=7289da&label=Discord&logo=discord&style=flat-square">
    </a>
    <a href="../../pulse">
	    <img src="https://img.shields.io/github/commit-activity/m/ProdigyAPI/ProdigyX?style=flat-square">
    </a>
</p>

THIS IS NOT MINE THIS IS PRODIGYX'S
<p align="center">
    <img alt="Prodigy X Menu" src="https://user-images.githubusercontent.com/63412264/188280311-13f2be0e-3afe-44ed-add7-9d1086e36a6e.png">
</p>
<br />
